from pyrogram import filters
from pyrogram.types import Message
from main import app  # Import the app instance from main.py
import os

OWNER_ID = int(os.getenv("OWNER_ID", "123456"))
CHANNEL_ID = os.getenv("CHANNEL_ID", "-1001234567890")  # Replace with your channel ID

@app.on_message(filters.command("start") & filters.private)
async def start_handler(client, message: Message):
    await message.reply_text("Hello! I'm alive and working fine.")

@app.on_message(filters.command("status") & filters.user(OWNER_ID))
async def status_handler(client, message: Message):
    await message.reply_text("✅ Bot is up and running.")

@app.on_message(filters.command("setchannel") & filters.user(OWNER_ID))
async def set_channel_handler(client, message: Message):
    if len(message.command) < 2:
        await message.reply_text("Please provide a channel ID.")
        return
    new_channel_id = message.command[1]
    os.environ["CHANNEL_ID"] = new_channel_id
    await message.reply_text(f"Channel ID updated to {new_channel_id}.")
